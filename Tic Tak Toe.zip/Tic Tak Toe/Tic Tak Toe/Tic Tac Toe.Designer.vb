﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblplayerO = New System.Windows.Forms.Label()
        Me.lblplayerX = New System.Windows.Forms.Label()
        Me.lable2 = New System.Windows.Forms.Label()
        Me.lable1 = New System.Windows.Forms.Label()
        Me.btnNewGame = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Tic_Tak_Toe.My.Resources.Resources._103_1035005_tick_tack_toe_clipart_clipground_pot_of_gumbo
        Me.PictureBox1.Location = New System.Drawing.Point(-2, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1388, 141)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(0, 142)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1386, 613)
        Me.Panel1.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.lblplayerO)
        Me.Panel3.Controls.Add(Me.lblplayerX)
        Me.Panel3.Controls.Add(Me.lable2)
        Me.Panel3.Controls.Add(Me.lable1)
        Me.Panel3.Controls.Add(Me.btnNewGame)
        Me.Panel3.Controls.Add(Me.Button11)
        Me.Panel3.Controls.Add(Me.Button10)
        Me.Panel3.Font = New System.Drawing.Font("Lucida Handwriting", 42.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel3.ForeColor = System.Drawing.Color.DarkRed
        Me.Panel3.Location = New System.Drawing.Point(714, 16)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(658, 574)
        Me.Panel3.TabIndex = 1
        '
        'lblplayerO
        '
        Me.lblplayerO.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lblplayerO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblplayerO.Font = New System.Drawing.Font("Microsoft Sans Serif", 49.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplayerO.Location = New System.Drawing.Point(369, 168)
        Me.lblplayerO.Name = "lblplayerO"
        Me.lblplayerO.Size = New System.Drawing.Size(263, 95)
        Me.lblplayerO.TabIndex = 15
        Me.lblplayerO.Text = "0"
        Me.lblplayerO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblplayerX
        '
        Me.lblplayerX.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lblplayerX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblplayerX.Font = New System.Drawing.Font("Microsoft Sans Serif", 49.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplayerX.Location = New System.Drawing.Point(369, 24)
        Me.lblplayerX.Name = "lblplayerX"
        Me.lblplayerX.Size = New System.Drawing.Size(263, 95)
        Me.lblplayerX.TabIndex = 14
        Me.lblplayerX.Text = "0"
        Me.lblplayerX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lable2
        '
        Me.lable2.AutoSize = True
        Me.lable2.Font = New System.Drawing.Font("Lucida Handwriting", 42.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lable2.ForeColor = System.Drawing.Color.DarkRed
        Me.lable2.Location = New System.Drawing.Point(24, 168)
        Me.lable2.Name = "lable2"
        Me.lable2.Size = New System.Drawing.Size(330, 91)
        Me.lable2.TabIndex = 13
        Me.lable2.Text = "O Win :"
        '
        'lable1
        '
        Me.lable1.AutoSize = True
        Me.lable1.Font = New System.Drawing.Font("Lucida Handwriting", 42.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lable1.ForeColor = System.Drawing.Color.DarkRed
        Me.lable1.Location = New System.Drawing.Point(24, 24)
        Me.lable1.Name = "lable1"
        Me.lable1.Size = New System.Drawing.Size(318, 91)
        Me.lable1.TabIndex = 12
        Me.lable1.Text = "X Win :"
        '
        'btnNewGame
        '
        Me.btnNewGame.BackColor = System.Drawing.Color.LightCoral
        Me.btnNewGame.Font = New System.Drawing.Font("Lucida Calligraphy", 49.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNewGame.Location = New System.Drawing.Point(14, 311)
        Me.btnNewGame.Name = "btnNewGame"
        Me.btnNewGame.Size = New System.Drawing.Size(626, 114)
        Me.btnNewGame.TabIndex = 11
        Me.btnNewGame.Text = "New Game"
        Me.btnNewGame.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.LightCoral
        Me.Button11.Font = New System.Drawing.Font("Lucida Calligraphy", 49.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(353, 440)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(287, 114)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "Exit"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.LightCoral
        Me.Button10.Font = New System.Drawing.Font("Lucida Calligraphy", 49.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(14, 440)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(333, 114)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "Reset"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.Button9)
        Me.Panel2.Controls.Add(Me.Button8)
        Me.Panel2.Controls.Add(Me.Button7)
        Me.Panel2.Controls.Add(Me.Button6)
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Controls.Add(Me.Button4)
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Location = New System.Drawing.Point(9, 16)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(700, 574)
        Me.Panel2.TabIndex = 0
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button9.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(462, 381)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(224, 181)
        Me.Button9.TabIndex = 8
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button8.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(234, 381)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(224, 181)
        Me.Button8.TabIndex = 7
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button7.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(7, 381)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(224, 181)
        Me.Button7.TabIndex = 6
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button6.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(463, 196)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(224, 181)
        Me.Button6.TabIndex = 5
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button5.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(235, 196)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(224, 181)
        Me.Button5.TabIndex = 4
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button4.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(8, 196)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(224, 181)
        Me.Button4.TabIndex = 3
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button3.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(462, 12)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(224, 181)
        Me.Button3.TabIndex = 2
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button2.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(235, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(224, 181)
        Me.Button2.TabIndex = 1
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button1.Font = New System.Drawing.Font("Lucida Handwriting", 96.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(7, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(224, 181)
        Me.Button1.TabIndex = 0
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CadetBlue
        Me.ClientSize = New System.Drawing.Size(1385, 755)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tic Tac Toe"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblplayerO As System.Windows.Forms.Label
    Friend WithEvents lblplayerX As System.Windows.Forms.Label
    Friend WithEvents lable2 As System.Windows.Forms.Label
    Friend WithEvents lable1 As System.Windows.Forms.Label
    Friend WithEvents btnNewGame As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
