﻿Public Class Form1

    Dim checker As Boolean
    Dim plusone As Integer
    Private Sub Enable_Flase()

        Button1.Enabled = False
        Button2.Enabled = False
        Button3.Enabled = False
        Button4.Enabled = False
        Button5.Enabled = False
        Button6.Enabled = False
        Button7.Enabled = False
        Button8.Enabled = False
        Button9.Enabled = False

    End Sub

    Private Sub score()
        If (Button1.Text = "X" And Button2.Text = "X" And Button3.Text = "X") Then
            Button1.BackColor = System.Drawing.Color.PowderBlue
            Button2.BackColor = Color.PowderBlue
            Button3.BackColor = System.Drawing.Color.PowderBlue
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerX.Text)
            lblplayerX.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button1.Text = "X" And Button4.Text = "X" And Button7.Text = "X") Then
            Button1.BackColor = System.Drawing.Color.Pink
            Button4.BackColor = System.Drawing.Color.Pink
            Button7.BackColor = System.Drawing.Color.Pink
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerX.Text)
            lblplayerX.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button1.Text = "X" And Button5.Text = "X" And Button9.Text = "X") Then
            Button1.BackColor = System.Drawing.Color.Crimson
            Button5.BackColor = System.Drawing.Color.Crimson
            Button9.BackColor = System.Drawing.Color.Crimson
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerX.Text)
            lblplayerX.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button3.Text = "X" And Button5.Text = "X" And Button7.Text = "X") Then
            Button3.BackColor = System.Drawing.Color.CadetBlue
            Button5.BackColor = System.Drawing.Color.CadetBlue
            Button7.BackColor = System.Drawing.Color.CadetBlue
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerX.Text)
            lblplayerX.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button2.Text = "X" And Button5.Text = "X" And Button8.Text = "X") Then
            Button2.BackColor = System.Drawing.Color.SlateBlue
            Button5.BackColor = System.Drawing.Color.SlateBlue
            Button8.BackColor = System.Drawing.Color.SlateBlue
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerX.Text)
            lblplayerX.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button3.Text = "X" And Button6.Text = "X" And Button9.Text = "X") Then
            Button3.BackColor = System.Drawing.Color.Violet
            Button6.BackColor = System.Drawing.Color.Violet
            Button9.BackColor = System.Drawing.Color.Violet
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerX.Text)
            lblplayerX.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button4.Text = "X" And Button5.Text = "X" And Button6.Text = "X") Then
            Button4.BackColor = System.Drawing.Color.DarkSlateBlue
            Button5.BackColor = System.Drawing.Color.DarkSlateBlue
            Button6.BackColor = System.Drawing.Color.DarkSlateBlue
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerX.Text)
            lblplayerX.Text = Convert.ToString(plusone)
            Enable_Flase()
        End If

        If (Button7.Text = "X" And Button8.Text = "X" And Button9.Text = "X") Then
            Button7.BackColor = System.Drawing.Color.DarkSlateBlue
            Button8.BackColor = System.Drawing.Color.DarkSlateBlue
            Button9.BackColor = System.Drawing.Color.DarkSlateBlue
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerX.Text)
            lblplayerX.Text = Convert.ToString(plusone)
            Enable_Flase()
        End If

        '=============================================

        If (Button1.Text = "O" And Button2.Text = "O" And Button3.Text = "O") Then

            Button1.BackColor = System.Drawing.Color.AliceBlue
            Button2.BackColor = Color.AliceBlue
            Button3.BackColor = System.Drawing.Color.AliceBlue
            MessageBox.Show("The Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerO.Text)
            lblplayerO.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button1.Text = "O" And Button4.Text = "O" And Button7.Text = "O") Then
            Button1.BackColor = System.Drawing.Color.LemonChiffon
            Button4.BackColor = System.Drawing.Color.LemonChiffon
            Button7.BackColor = System.Drawing.Color.LemonChiffon
            MessageBox.Show("The Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerO.Text)
            lblplayerO.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button1.Text = "O" And Button5.Text = "O" And Button9.Text = "O") Then
            Button1.BackColor = System.Drawing.Color.BlueViolet
            Button5.BackColor = System.Drawing.Color.BlueViolet
            Button9.BackColor = System.Drawing.Color.BlueViolet
            MessageBox.Show("The Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerO.Text)
            lblplayerO.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button3.Text = "O" And Button5.Text = "O" And Button7.Text = "O") Then
            Button3.BackColor = System.Drawing.Color.NavajoWhite
            Button5.BackColor = System.Drawing.Color.NavajoWhite
            Button7.BackColor = System.Drawing.Color.NavajoWhite
            MessageBox.Show("The Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerO.Text)
            lblplayerO.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button2.Text = "O" And Button5.Text = "O" And Button8.Text = "O") Then
            Button2.BackColor = System.Drawing.Color.SandyBrown
            Button5.BackColor = System.Drawing.Color.SandyBrown
            Button8.BackColor = System.Drawing.Color.SandyBrown
            MessageBox.Show("The Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerO.Text)
            lblplayerO.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button3.Text = "O" And Button6.Text = "O" And Button9.Text = "O") Then
            Button3.BackColor = System.Drawing.Color.SeaGreen
            Button6.BackColor = System.Drawing.Color.SeaGreen
            Button9.BackColor = System.Drawing.Color.SeaGreen
            MessageBox.Show("The Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerO.Text)
            lblplayerO.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button4.Text = "O" And Button5.Text = "O" And Button6.Text = "O") Then
            Button4.BackColor = System.Drawing.Color.Azure
            Button5.BackColor = System.Drawing.Color.Azure
            Button6.BackColor = System.Drawing.Color.Azure
            MessageBox.Show("The Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerO.Text)
            lblplayerO.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

        If (Button7.Text = "O" And Button8.Text = "O" And Button9.Text = "O") Then
            Button7.BackColor = System.Drawing.Color.DarkBlue
            Button8.BackColor = System.Drawing.Color.DarkBlue
            Button9.BackColor = System.Drawing.Color.DarkBlue
            MessageBox.Show("The Winner is Player x", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            plusone = Convert.ToInt64(lblplayerO.Text)
            lblplayerO.Text = Convert.ToString(plusone + 1)
            Enable_Flase()
        End If

    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (checker = False) Then
            Button1.Text = "X"
            checker = True
        Else
            Button1.Text = "O"
            checker = False

        End If
        score()
        Button1.Enabled = False

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If (checker = False) Then
            Button2.Text = "X"
            checker = True
        Else
            Button2.Text = "O"
            checker = False

        End If
        score()
        Button2.Enabled = False

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If (checker = False) Then
            Button3.Text = "X"
            checker = True
        Else
            Button3.Text = "O"
            checker = False

        End If
        score()
        Button3.Enabled = False

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If (checker = False) Then
            Button4.Text = "X"
            checker = True
        Else
            Button4.Text = "O"
            checker = False

        End If
        score()
        Button4.Enabled = False

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If (checker = False) Then
            Button5.Text = "X"
            checker = True
        Else
            Button5.Text = "O"
            checker = False

        End If
        score()
        Button5.Enabled = False

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If (checker = False) Then
            Button6.Text = "X"
            checker = True
        Else
            Button6.Text = "O"
            checker = False

        End If
        score()
        Button6.Enabled = False

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If (checker = False) Then
            Button7.Text = "X"
            checker = True
        Else
            Button7.Text = "O"
            checker = False

        End If
        score()
        Button7.Enabled = False

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        If (checker = False) Then
            Button8.Text = "X"
            checker = True
        Else
            Button8.Text = "O"
            checker = False

        End If
        score()
        Button8.Enabled = False

    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        If (checker = False) Then
            Button9.Text = "X"
            checker = True
        Else
            Button9.Text = "O"
            checker = False

        End If
        score()
        Button9.Enabled = False

    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewGame.Click
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Button5.Enabled = True
        Button6.Enabled = True
        Button7.Enabled = True
        Button8.Enabled = True
        Button9.Enabled = True

        Button1.Text = ""
        Button2.Text = ""
        Button3.Text = ""
        Button4.Text = ""
        Button5.Text = ""
        Button6.Text = ""
        Button7.Text = ""
        Button8.Text = ""
        Button9.Text = ""

        lblplayerX.Text = "0"
        lblplayerO.Text = "0"

        Button1.BackColor = System.Drawing.Color.WhiteSmoke
        Button2.BackColor = Color.WhiteSmoke
        Button3.BackColor = Color.WhiteSmoke
        Button4.BackColor = Color.WhiteSmoke
        Button5.BackColor = Color.WhiteSmoke
        Button6.BackColor = Color.WhiteSmoke
        Button7.BackColor = Color.WhiteSmoke
        Button8.BackColor = Color.WhiteSmoke
        Button9.BackColor = Color.WhiteSmoke
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Button5.Enabled = True
        Button6.Enabled = True
        Button7.Enabled = True
        Button8.Enabled = True
        Button9.Enabled = True

        Button1.Text = ""
        Button2.Text = ""
        Button3.Text = ""
        Button4.Text = ""
        Button5.Text = ""
        Button6.Text = ""
        Button7.Text = ""
        Button8.Text = ""
        Button9.Text = ""

        btnNewGame.Enabled = True

        Button1.BackColor = System.Drawing.Color.WhiteSmoke
        Button2.BackColor = Color.WhiteSmoke
        Button3.BackColor = Color.WhiteSmoke
        Button4.BackColor = Color.WhiteSmoke
        Button5.BackColor = Color.WhiteSmoke
        Button6.BackColor = Color.WhiteSmoke
        Button7.BackColor = Color.WhiteSmoke
        Button8.BackColor = Color.WhiteSmoke
        Button9.BackColor = Color.WhiteSmoke
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Dim iexit As DialogResult
        iexit = MessageBox.Show("confirm if want to exit", "system down", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If iexit = DialogResult.Yes Then
            Application.Exit()

        End If
    End Sub

End Class


